#!/bin/sh

# Doom Launcher for K1 Max
# Stops any screen software, enables framebuffer, and launches Doom

DOOM_DIR="/usr/data/Doom"
DOOM_BIN="$DOOM_DIR/doom_k1max"
DOOM_WAD="$DOOM_DIR/doom1.wad"

echo "=== K1 Max Doom Launcher ==="

# Kill all known screen software that might hold the framebuffer
echo "Stopping screen software..."
killall helix-screen 2>/dev/null
killall helix-watchdog 2>/dev/null
killall helix-launcher.sh 2>/dev/null
killall CrealityScreen 2>/dev/null
killall crealityscreen 2>/dev/null
killall guppyscreen 2>/dev/null
killall GuppyScreen 2>/dev/null

# Give processes time to clean up
sleep 2

# Kill any remaining processes using the framebuffer
echo "Clearing framebuffer..."
fuser -k /dev/fb0 2>/dev/null
sleep 1

# Enable framebuffer
echo "Enabling framebuffer..."
cmd_fb enable /dev/fb0

# Set correct permissions on Doom files
echo "Setting permissions..."
chmod 755 "$DOOM_BIN"
chmod 644 "$DOOM_WAD"

# Check if files exist
if [ ! -f "$DOOM_BIN" ]; then
    echo "ERROR: Doom binary not found at $DOOM_BIN"
    exit 1
fi

if [ ! -f "$DOOM_WAD" ]; then
    echo "ERROR: Doom WAD file not found at $DOOM_WAD"
    exit 1
fi

# Launch Doom
echo "Launching Doom..."
echo "Use Ctrl+C to exit"
sleep 1

cd "$DOOM_DIR"
"$DOOM_BIN" -iwad "$DOOM_WAD" -warp 1 3

# Cleanup message
echo ""
echo "Doom exited. You may need to restart your screen software."
